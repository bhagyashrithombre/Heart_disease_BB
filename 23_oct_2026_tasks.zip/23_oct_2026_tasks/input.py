import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os

st.set_page_config(page_title="Heart Disease Prediction", layout="centered")

@st.cache_resource
def load_model():
    if not os.path.exists(MODEL_PATH):
        return None
    return joblib.load(MODEL_PATH)

model = load_model()

st.title("Heart Disease Prediction")

if model is None:
    st.error("Model file not found. Check the model path.")
    st.stop()


BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(
    BASE_DIR,
    "saved_models",
    "heart_model_v20261013_160903.joblib"
)

if not os.path.isfile(MODEL_PATH):
    st.error("Copy the model file into the saved_models folder shown above.")
    st.stop()

model = joblib.load(MODEL_PATH)
st.success("Model loaded successfully.")

st.write("Enter the patient's details.")
with st.form("prediction_form"):
    age = st.number_input("Age", min_value=1, max_value=120, value=45)
    sex = st.selectbox("Sex", [0, 1])
    cp = st.selectbox("Chest Pain Type", [0, 1, 2, 3])
    trestbps = st.number_input("Resting Blood Pressure", min_value=50, max_value=300, value=120)
    chol = st.number_input("Cholesterol", min_value=50, max_value=700, value=200)
    fbs = st.selectbox("Fasting Blood Sugar", [0, 1])
    restecg = st.selectbox("Resting ECG", [0, 1, 2])
    thalach = st.number_input("Maximum Heart Rate", min_value=40, max_value=250, value=150)
    exang = st.selectbox("Exercise-Induced Angina", [0, 1])
    oldpeak = st.number_input("ST Depression", min_value=0.0, max_value=10.0, value=1.0)
    slope = st.selectbox("ST Slope", [0, 1, 2])
    ca = st.selectbox("Number of Major Vessels", [0, 1, 2, 3, 4])
    thal = st.selectbox("Thalassemia", [0, 1, 2, 3])

    submitted = st.form_submit_button("Predict")

if submitted:
    try:
        values = {
            "age": age,
            "sex": sex,
            "cp": cp,
            "trestbps": trestbps,
            "chol": chol,
            "fbs": fbs,
            "restecg": restecg,
            "thalach": thalach,
            "exang": exang,
            "oldpeak": oldpeak,
            "slope": slope,
            "ca": ca,
            "thal": thal
        }

        input_df = pd.DataFrame([values])

        if input_df.isnull().any().any():
            st.error("Please fill in all input values.")
        elif not np.isfinite(input_df.to_numpy(dtype=float)).all():
            st.error("Input contains invalid numeric values.")
        else:
            expected_features = getattr(model, "feature_names_in_", None)

            if expected_features is not None:
                missing_features = set(expected_features) - set(input_df.columns)
                extra_features = set(input_df.columns) - set(expected_features)

                if missing_features or extra_features:
                    st.error(
                        "Input features do not match the trained model. "
                        f"Missing: {sorted(missing_features)}; "
                        f"Extra: {sorted(extra_features)}"
                    )
                    st.stop()

                input_df = input_df[list(expected_features)]

            prediction = model.predict(input_df)[0]

            st.subheader("Prediction Result")

            if prediction == 1:
                st.warning("The model predicts a possible presence of heart disease.")
            else:
                st.success("The model predicts no heart disease.")

            if hasattr(model, "predict_proba"):
                probabilities = model.predict_proba(input_df)[0]
                st.write("Prediction probabilities:")

                for label, probability in zip(model.classes_, probabilities):
                    st.write(f"Class {label}: {probability * 100:.2f}%")

    except (ValueError, TypeError) as error:
        st.error(f"Invalid input: {error}")
    except Exception as error:
        st.error(f"Prediction failed: {error}")