# Heart Disease Prediction — Streamlit UI

A responsive Streamlit interface styled with custom HTML/CSS. It avoids Streamlit layout helpers such as `st.columns()`, `st.sidebar`, and `st.container()`.

## Files
- `app.py` — Streamlit application
- `requirements.txt` — Python dependencies
- `README.md` — setup and usage instructions

## 1. Install dependencies
```bash
python -m pip install -r requirements.txt
```

## 2. Add your trained model
Copy your fitted model or, preferably, your complete fitted preprocessing/model pipeline into this folder with the filename:

`heart_disease_model.joblib`

From your training notebook:
```python
import joblib
joblib.dump(best_model, "heart_disease_model.joblib")
```

The model must be trained with the same input features and compatible encodings as the UI. If the model was trained on a DataFrame, its `feature_names_in_` will be used when available. Otherwise, the app assumes the common 13-feature heart-disease dataset field list in `app.py`; update that list to match your model.

## 3. Run the app
```bash
streamlit run app.py
```

## Notes
- Keep feature names, feature order, preprocessing, and category encoding consistent with training.
- For a preprocessing workflow, save the entire fitted scikit-learn `Pipeline`, not just the final estimator.
- This demo is not a medical device and does not provide a diagnosis.
